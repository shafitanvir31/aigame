import argparse, random, subprocess, time, os, sys, pygame
from graphics import CELL_SIZE, draw_board, BG, RED, BLUE, get_font

parser = argparse.ArgumentParser()
parser.add_argument('--red',  choices=['ai', 'random'], default='ai')
parser.add_argument('--blue', choices=['ai', 'random'], default='ai')

parser.add_argument('--red-depth',      default='3')
parser.add_argument('--blue-depth',     default='3')
parser.add_argument('--red-heuristic',  default='0')
parser.add_argument('--blue-heuristic', default='0')
parser.add_argument('--fps',            type=int, default=30,
                    help='Render frame-rate (0 = headless)')

args = parser.parse_args()
ROWS, COLS = 9, 6
WIDTH, HEIGHT = COLS * CELL_SIZE, ROWS * CELL_SIZE

FILE_PATH = os.path.join(os.path.dirname(__file__), '..', 'gamestate.txt')
ENGINE     = os.path.join(os.path.dirname(__file__), '..',
                          'backend', 'build', 'chain_reaction_engine')
if sys.platform == "win32":
    ENGINE += ".exe"

if args.fps > 0:
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption('Chain Reaction – Arena')
    clock = pygame.time.Clock()

board   = [['0' for _ in range(COLS)] for _ in range(ROWS)]
header  = 'AI Move:'              # Red always starts
turn_no = 0
ai_proc = None
game_over = False
winner     = None

def write_board(next_header: str):
    """Dump in-memory board + header back to the shared txt file."""
    with open(FILE_PATH, 'w') as f:
        f.write(next_header + '\n')
        for r in range(ROWS):
            f.write(' '.join(board[r]) + '\n')

def parse_file():
    global header
    with open(FILE_PATH) as f:
        lines = f.read().strip().split('\n')
    header = lines[0]
    for r, line in enumerate(lines[1:ROWS+1]):
        board[r] = line.split()

def legal_moves(player_char: str):
    moves = []
    for r in range(ROWS):
        for c in range(COLS):
            tok = board[r][c]
            if tok == '0' or tok[1] == player_char:
                moves.append((r, c))
    return moves

def random_move(player_char: str):
    """Execute one random legal move for player_char ('R' or 'B')."""
    global turn_no
    moves = legal_moves(player_char)
    if not moves:
        return
    r, c = random.choice(moves)
    tok = board[r][c]
    if tok == '0':
        board[r][c] = f'1{player_char}'
    else:
        board[r][c] = f'{int(tok[0]) + 1}{player_char}'
    turn_no += 1
    next_header = 'Human Move:' if player_char == 'R' else 'AI Move:'
    write_board(next_header)

def check_game_over():
    global game_over, winner
    if turn_no < 2:
        return
    red_present  = any('R' in cell for row in board for cell in row)
    blue_present = any('B' in cell for row in board for cell in row)
    if red_present and not blue_present:
        winner, game_over = 'RED', True
    elif blue_present and not red_present:
        winner, game_over = 'BLUE', True

def render():
    if args.fps == 0: 
        return
    screen.fill(BG)
    draw_board(screen, board)
    if ai_proc and ai_proc.poll() is None:
        font = get_font(36)
        surf = font.render("AI thinking…", True, (255, 255, 255))
        screen.blit(surf, surf.get_rect(center=(WIDTH//2, HEIGHT//2)))
    if game_over:
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 150))
        screen.blit(overlay, (0, 0))
        win_color = RED if winner == 'RED' else BLUE
        font = get_font(50)
        text = font.render(f"{winner} WINS!", True, win_color)
        screen.blit(text, text.get_rect(center=(WIDTH//2, HEIGHT//2)))
    pygame.display.flip()


write_board(header)


running = True
while running:

    if args.fps > 0:
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                running = False


    if ai_proc and ai_proc.poll() is not None:
        ai_proc = None
        parse_file()
        turn_no += 1
        check_game_over()

    if not ai_proc and not game_over:
        parse_file()

        if header == 'AI Move:':        
            if args.red == 'ai':
                ai_proc = subprocess.Popen(
                    [ENGINE, FILE_PATH, 'R',
                     args.red_depth, args.red_heuristic])
            else:                          
                random_move('R')
                check_game_over()
        else:                             
            if args.blue == 'ai':
                ai_proc = subprocess.Popen(
                    [ENGINE, FILE_PATH, 'B',
                     args.blue_depth, args.blue_heuristic])
            else:                       
                random_move('B')
                check_game_over()

    render()
    if args.fps > 0:
        clock.tick(args.fps)

pygame.quit()
